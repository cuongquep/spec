/// <reference types="react-scripts" />

declare module "cytoscape-klay";
declare module "cytoscape-dagre";
declare module "cytoscape-svg";
