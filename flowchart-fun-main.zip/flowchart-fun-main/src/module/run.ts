#!/usr/bin/env node
import { generate } from "./generate";

generate();
