export const generate = () => {
  console.log("flowchart-fun");
};
